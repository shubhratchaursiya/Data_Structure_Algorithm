#include <stdio.h>
#include <stdlib.h>

#define MAX 5  // Fixed capacity of the deque

typedef struct ORDeque {
    int arr[MAX];
    int front;
    int rear;
} ORDeque;

// Function to create an output-restricted deque
void initializeDeque(ORDeque *deque) {
    deque->front = deque->rear = -1;
}

// Function to check if the deque is empty
int isEmpty(ORDeque *deque) {
    return deque->front == -1;
}

// Function to check if the deque is full
int isFull(ORDeque *deque) {
    return deque->rear == MAX - 1;
}

// Function to insert at front
void insertFront(ORDeque *deque, int value) {
    if (isFull(deque)) {
        printf("Deque Overflow! Cannot insert %d.\n", value);
        return;
    }
    if (isEmpty(deque)) {
        deque->front = deque->rear = 0;
    } else if (deque->front == 0) {
        printf("Cannot insert at front. Front position is already at the beginning.\n");
        return;
    } else {
        deque->front--;
    }
    deque->arr[deque->front] = value;
    printf("%d inserted at the front of the deque.\n", value);
}

// Function to delete from rear
int deleteRear(ORDeque *deque) {
    if (isEmpty(deque)) {
        printf("Deque Underflow! Cannot delete from rear.\n");
        return -1;
    }
    int deletedValue = deque->arr[deque->rear];
    if (deque->front == deque->rear) {
        deque->front = deque->rear = -1; // Deque becomes empty
    } else {
        deque->rear--;
    }
    printf("%d deleted from the rear of the deque.\n", deletedValue);
    return deletedValue;
}

// Function to display the deque
void displayORDeque(ORDeque *deque) {
    if (isEmpty(deque)) {
        printf("Deque is empty!\n");
        return;
    }
    printf("Deque elements: ");
    for (int i = deque->front; i <= deque->rear; i++) {
        printf("%d ", deque->arr[i]);
    }
    printf("\n");
}

int main() {
    ORDeque deque;
    initializeDeque(&deque);
    int choice, value;

    do {
        printf("\n1. Insert at Front\n2. Delete from Rear\n3. Display Deque\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert at front: ");
                scanf("%d", &value);
                insertFront(&deque, value);
                break;
            case 2:
                deleteRear(&deque);
                break;
            case 3:
                displayORDeque(&deque);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while (choice != 4);

    return 0;
}