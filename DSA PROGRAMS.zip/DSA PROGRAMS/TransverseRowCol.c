#include <stdio.h>

void traverseRowMajor(int arr[3][3], int rows, int cols) {
    printf("Row Major Traversal:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
}

void traverseColumnMajor(int arr[3][3], int rows, int cols) {
    printf("Column Major Traversal:\n");
    for (int j = 0; j < cols; j++) {
        for (int i = 0; i < rows; i++) {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int arr[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    traverseRowMajor(arr, 3, 3);
    traverseColumnMajor(arr, 3, 3);

    return 0;
}