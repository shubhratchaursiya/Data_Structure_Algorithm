#include <stdio.h>
#include <stdlib.h>

typedef struct IRDeque {
    int *arr;
    int front;
    int rear;
    int capacity;
} IRDeque;

IRDeque* createIRDeque(int capacity) {
    IRDeque *deque = (IRDeque *)malloc(sizeof(IRDeque));
    deque->capacity = capacity;
    deque->front = deque->rear = -1;
    deque->arr = (int *)malloc(capacity * sizeof(int));
    return deque;
}

int isEmpty(IRDeque *deque) {
    return deque->front == -1;
}

int isFull(IRDeque *deque) {
    return deque->rear == deque->capacity - 1;
}

void insertRear(IRDeque *deque, int value) {
    if (isFull(deque)) {
        printf("Deque Overflow! Cannot insert %d.\n", value);
        return;
    }
    if (isEmpty(deque)) {
        deque->front = deque->rear = 0;
    } else {
        deque->rear++;
    }
    deque->arr[deque->rear] = value;
    printf("%d inserted at the rear of the deque.\n", value);
}

int deleteFront(IRDeque *deque) {
    if (isEmpty(deque)) {
        printf("Deque Underflow! Cannot delete from front.\n");
        return -1;
    }
    int deletedValue = deque->arr[deque->front];
    if (deque->front == deque->rear) {
        deque->front = deque->rear = -1;
    } else {
        deque->front++;
    }
    printf("%d deleted from the front of the deque.\n", deletedValue);
    return deletedValue;
}

void displayIRDeque(IRDeque *deque) {
    if (isEmpty(deque)) {
        printf("Deque is empty!\n");
        return;
    }
    printf("Deque elements: ");
    for (int i = deque->front; i <= deque->rear; i++) {
        printf("%d ", deque->arr[i]);
    }
    printf("\n");
}

int main() {
    int capacity;
    printf("Enter the capacity of the input-restricted deque: ");
    scanf("%d", &capacity);

    IRDeque *deque = createIRDeque(capacity);
    int choice, value;

    do {
        printf("\n1. Insert at Rear\n2. Delete from Front\n3. Display Deque\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert at rear: ");
                scanf("%d", &value);
                insertRear(deque, value);
                break;
            case 2:
                deleteFront(deque);
                break;
            case 3:
                displayIRDeque(deque);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while (choice != 4);

    free(deque->arr);
    free(deque);
    return 0;
}