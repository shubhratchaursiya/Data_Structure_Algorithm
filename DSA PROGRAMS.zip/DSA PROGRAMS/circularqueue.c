#include <stdio.h>
#include <stdlib.h>

#define MAX 5 // Maximum size of the queue

typedef struct {
    int arr[MAX];
    int front;
    int rear;
} CircularQueue;
// Initialize the circular queue
void init(CircularQueue *q) {
    q->front = -1;
    q->rear = -1;
}

// Check if the queue is empty
int isEmpty(CircularQueue *q) {
    return q->front == -1;
}

// Check if the queue is full
int isFull(CircularQueue *q) {
    return (q->rear + 1) % MAX == q->front;
}

// Enqueue operation to add an element to the queue
void enqueue(CircularQueue *q, int data) {
    if (isFull(q)) {
        printf("Queue overflow\n");
        return;
    }
    if (isEmpty(q)) {
        q->front = 0;
    }
    q->rear = (q->rear + 1) % MAX;
    q->arr[q->rear] = data;
    printf("%d enqueued to queue\n", data);
}

// Dequeue operation to remove an element from the front of the queue
int dequeueFront(CircularQueue *q) {
    if (isEmpty(q)) {
        printf("Queue underflow\n");
        return -1;
    }
    int data = q->arr[q->front];
    if (q->front == q->rear) {
        q->front = q->rear = -1; // Reset queue if it's empty after dequeuing
    } else {
        q->front = (q->front + 1) % MAX;
    }
    return data;
}

// Dequeue operation to remove an element from the rear of the queue
int dequeueRear(CircularQueue *q) {
    if (isEmpty(q)) {
        printf("Queue underflow\n");
        return -1;
    }
    int data = q->arr[q->rear];
    if (q->front == q->rear) {
        q->front = q->rear = -1; // Reset queue if it's empty after dequeuing
    } else {
        q->rear = (q->rear - 1 + MAX) % MAX;
    }
    return data;
}

// Peek operation to return the front element of the queue
int peek(CircularQueue *q) {
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return -1;
    }
    return q->arr[q->front];
}

// Display operation to show all elements in the queue
void display(CircularQueue *q) {
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return;
    }
    printf("Queue elements: ");
    int i = q->front;
    while (1) {
        printf("%d ", q->arr[i]);
        if (i == q->rear) break;
        i = (i + 1) % MAX;
    }
    printf("\n");
}
int main() {
    CircularQueue q;
    init(&q);

    enqueue(&q, 10);
    enqueue(&q, 20);
    enqueue(&q, 30);
    enqueue(&q, 40);
    enqueue(&q, 50); // This should trigger "Queue overflow" as the queue is full

    display(&q);

    printf("Front element is %d\n", peek(&q));

    printf("%d dequeued from front\n", dequeueFront(&q));
    printf("%d dequeued from rear\n", dequeueRear(&q));

    display(&q);

    printf("Is queue empty? %s\n", isEmpty(&q) ? "Yes" : "No");

    printf("%d dequeued from front\n", dequeueFront(&q));
    printf("%d dequeued from rear\n", dequeueRear(&q));
    printf("%d dequeued from front\n", dequeueFront(&q));
    printf("%d dequeued from rear\n", dequeueRear(&q)); // Trying to dequeue from an empty queue

    return 0;
}

