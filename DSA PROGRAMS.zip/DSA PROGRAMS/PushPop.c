#include <stdio.h>
#define MAX 10

int stack[MAX];
int top1 = -1, top2 = MAX;

void push1(int value) {
    if (top1 < top2 - 1) {
        stack[++top1] = value;
    } else {
        printf("Stack Overflow!\n");
    }
}

void push2(int value) {
    if (top1 < top2 - 1) {
        stack[--top2] = value;
    } else {
        printf("Stack Overflow!\n");
    }
}

int pop1() {
    if (top1 >= 0) {
        return stack[top1--];
    } else {
        printf("Stack Underflow!\n");
        return -1;
    }
}

int pop2() {
    if (top2 < MAX) {
        return stack[top2++];
    } else {
        printf("Stack Underflow!\n");
        return -1;
    }
}

int main() {
    push1(10);
    push1(20);
    push2(100);
    push2(200);

    printf("Popped from stack 1: %d\n", pop1());
    printf("Popped from stack 2: %d\n", pop2());

    return 0;
}