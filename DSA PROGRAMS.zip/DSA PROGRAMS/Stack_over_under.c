#include <stdio.h>
#include <stdlib.h>
int main() {
    int n, *stack, choice, top = -1, val;
    printf("Enter the size of the stack: ");
    scanf("%d", &n);
    stack = (int*)malloc(n * sizeof(int));
    if (stack == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }
    printf("\n1. Insertion (Push)\n2. Deletion (Pop)\n3. Display\n4. Exit\n");
    while (1) {
        printf("\nEnter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                if (top == n - 1) {
                    printf("Stack Overflow\n");
                } else {
                    printf("Enter the value to push: ");
                    scanf("%d", &val);
                    stack[++top] = val;
                    printf("%d pushed into the stack.\n", val);
                }
                break;
            case 2:
                if (top == -1) {
                    printf("Stack Underflow\n");
                } else {
                    printf("%d popped from the stack.\n", stack[top--]);
                }
                break;
            case 3:
                if (top == -1) {
                    printf("Stack is empty.\n");
                } else {
                    printf("Stack elements are: ");
                    for (int i = 0; i <= top; i++) {
                        printf("%d ", stack[i]);
                    }
                    printf("\n");
                }
                break;
            case 4:
                free(stack);
                printf("Exiting...\n");
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}