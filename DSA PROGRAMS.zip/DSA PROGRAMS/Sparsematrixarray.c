#include <stdio.h>
#include <stdlib.h>

// Define the structure for non-zero elements
struct Element {
    int row;
    int col;
    int value;
};

typedef struct Element Element;
// Function to create the sparse matrix representation
Element* createSparseMatrix(int **matrix, int rows, int cols, int *size) {
    // Count the number of non-zero elements
    int count = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (matrix[i][j] != 0) {
                count++;
            }
        }
    }

    // Allocate memory for the array of non-zero elements
    Element *sparseMatrix = (Element*)malloc(count * sizeof(Element));
    *size = count;

    // Store the non-zero elements along with their row and column indices
    int index = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (matrix[i][j] != 0) {
                sparseMatrix[index].row = i;
                sparseMatrix[index].col = j;
                sparseMatrix[index].value = matrix[i][j];
                index++;
            }
        }
    }

    return sparseMatrix;
}
// Function to display the sparse matrix representation
void displaySparseMatrix(Element *sparseMatrix, int size) {
    printf("Row  Column  Value\n");
    for (int i = 0; i < size; i++) {
        printf("%d    %d      %d\n", sparseMatrix[i].row, sparseMatrix[i].col, sparseMatrix[i].value);
    }
}
int main() {
    int rows = 4;
    int cols = 5;
    int matrix[4][5] = {
        {0, 0, 3, 0, 4},
        {0, 0, 5, 7, 0},
        {0, 0, 0, 0, 0},
        {0, 2, 6, 0, 0}
    };

    // Allocate memory for the dynamic 2D array
    int **dynamicMatrix = (int **)malloc(rows * sizeof(int *));
    for (int i = 0; i < rows; i++) {
        dynamicMatrix[i] = (int *)malloc(cols * sizeof(int));
        for (int j = 0; j < cols; j++) {
            dynamicMatrix[i][j] = matrix[i][j];
        }
    }

    int size;
    Element *sparseMatrix = createSparseMatrix(dynamicMatrix, rows, cols, &size);

    printf("Sparse Matrix Representation:\n");
    displaySparseMatrix(sparseMatrix, size);

    // Free allocated memory
    for (int i = 0; i < rows; i++) {
        free(dynamicMatrix[i]);
    }
    free(dynamicMatrix);
    free(sparseMatrix);

    return 0;
}
