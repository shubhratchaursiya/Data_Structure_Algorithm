#include<stdio.h>
#include<conio.h>
int main(){
    int arr[5],i,max,min;
    printf("enter the element");
    for(int i=0;i<5;i++){
        scanf("%d", &arr[i]);
        max=arr[0];
        min=arr[0];
        for(int i=0;i<5;i++){
            if(arr[i]>max){
                max=arr[i];

            }
        
         else  if(arr[i]<min){
            min=arr[i];
         }
    }}
    printf("maximum value is %d",max);
    printf("minimum value is %d",min);
    }

#include<stdio.h>
#include<conio.h>
int main(){
    int arr[5],i,max,min;
    printf("enter the element");
    for(int i=0;i<5;i++){
        scanf("%d", &arr[i]);
        max=arr[0];
        min=arr[0];
        for(int i=0;i<5;i++){
            if(arr[i]>max){
                max=arr[i];

            }
        
         else  if(arr[i]<min){
            min=arr[i];
         }
    }}
    printf("maximum value is %d",max);
    printf("minimum value is %d",min);
    }

#include<stdio.h>
#include<conio.h>
int main(){
    int arr[5],i,max,min;
    printf("enter the element");
    for(int i=0;i<5;i++){
        scanf("%d", &arr[i]);
        max=arr[0];
        min=arr[0];
        for(int i=0;i<5;i++){
            if(arr[i]>max){
                max=arr[i];

            }
        
         else  if(arr[i]<min){
            min=arr[i];
         }
    }}
    printf("maximum value is %d",max);
    printf("minimum value is %d",min);
    }