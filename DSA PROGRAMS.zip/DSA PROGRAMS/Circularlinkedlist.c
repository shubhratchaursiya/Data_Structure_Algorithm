#include <stdio.h>
#include <stdlib.h>

// Define the node structure
struct Node {
    int data;
    struct Node* next;
};

typedef struct Node Node;
// Function to insert a node at the beginning of the circular linked list
void insertAtBeginning(Node** head, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    if (*head == NULL) {
        newNode->next = newNode; // Point to itself
        *head = newNode;
    } else {
        Node* temp = *head;
        while (temp->next != *head) {
            temp = temp->next;
        }
        newNode->next = *head;
        temp->next = newNode;
        *head = newNode;
    }
    printf("%d inserted at the beginning\n", data);
}

// Function to insert a node at the end of the circular linked list
void insertAtEnd(Node** head, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    if (*head == NULL) {
        newNode->next = newNode; // Point to itself
        *head = newNode;
    } else {
        Node* temp = *head;
        while (temp->next != *head) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->next = *head;
    }
    printf("%d inserted at the end\n", data);
}

// Function to insert a node at a specific position in the circular linked list
void insertAtPosition(Node** head, int data, int position) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;

    if (position == 1) {
        insertAtBeginning(head, data);
        return;
    }

    Node* temp = *head;
    for (int i = 1; i < position - 1 && temp->next != *head; i++) {
        temp = temp->next;
    }

    if (temp->next == *head && position > 1) {
        printf("Position out of range\n");
        free(newNode);
    } else {
        newNode->next = temp->next;
        temp->next = newNode;
        printf("%d inserted at position %d\n", data, position);
    }
}

// Function to delete a node at the beginning of the circular linked list
void deleteAtBeginning(Node** head) {
    if (*head == NULL) {
        printf("List is empty\n");
        return;
    }

    Node* temp = *head;
    Node* last = *head;

    while (last->next != *head) {
        last = last->next;
    }

    if (*head == last) {
        *head = NULL;
    } else {
        *head = temp->next;
        last->next = *head;
    }

    printf("%d deleted from the beginning\n", temp->data);
    free(temp);
}

// Function to delete a node at the end of the circular linked list
void deleteAtEnd(Node** head) {
    if (*head == NULL) {
        printf("List is empty\n");
        return;
    }

    Node* temp = *head;
    Node* prev = NULL;

    while (temp->next != *head) {
        prev = temp;
        temp = temp->next;
    }

    if (prev == NULL) {
        *head = NULL;
    } else {
        prev->next = *head;
    }

    printf("%d deleted from the end\n", temp->data);
    free(temp);
}

// Function to delete a node at a specific position in the circular linked list
void deleteAtPosition(Node** head, int position) {
    if (*head == NULL) {
        printf("List is empty\n");
        return;
    }

    Node* temp = *head;
    if (position == 1) {
        deleteAtBeginning(head);
        return;
    }

    Node* prev = NULL;
    for (int i = 1; i < position && temp->next != *head; i++) {
        prev = temp;
        temp = temp->next;
    }

    if (temp->next == *head && position > 1) {
        printf("Position out of range\n");
    } else {
        prev->next = temp->next;
        printf("%d deleted from position %d\n", temp->data, position);
        free(temp);
    }
}

// Function to display the circular linked list
void display(Node* head) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    Node* temp = head;
    printf("Circular Linked List: ");
    do {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != head);
    printf("%d (head)\n", head->data);
}
int main() {
    Node* head = NULL;

    insertAtBeginning(&head, 10);
    insertAtEnd(&head, 20);
    insertAtBeginning(&head, 5);
    insertAtPosition(&head, 15, 3);
    insertAtPosition(&head, 25, 5);

    display(head);

    deleteAtBeginning(&head);
    deleteAtEnd(&head);
    deleteAtPosition(&head, 2);

    display(head);

    return 0;
}
