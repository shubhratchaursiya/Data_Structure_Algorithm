#include <stdio.h>
#include <stdlib.h>

// Define the node structure
struct Node {
    int data;
    struct Node* next;
};

typedef struct Node Node;
// Push operation to add an element to the stack
void push(Node** top, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) {
        printf("Stack overflow\n");
        exit(1);
    }
    newNode->data = data;
    newNode->next = *top;
    *top = newNode;
    printf("%d pushed onto stack\n", data);
}

// Pop operation to remove an element from the stack
void pop(Node** top) {
    if (*top == NULL) {
        printf("Stack underflow\n");
        return;
    }
    Node* temp = *top;
    *top = (*top)->next;
    printf("%d popped from stack\n", temp->data);
    free(temp);
}

// Peek operation to return the top element of the stack
int peek(Node* top) {
    if (top == NULL) {
        printf("Stack is empty\n");
        return -1;
    }
    return top->data;
}

// isEmpty operation to check if the stack is empty
int isEmpty(Node* top) {
    return top == NULL;
}

// Display operation to show all elements in the stack
void display(Node* top) {
    if (top == NULL) {
        printf("Stack is empty\n");
        return;
    }
    Node* temp = top;
    printf("Stack elements: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}
int main() {
    Node* stack = NULL;

    push(&stack, 10);
    push(&stack, 20);
    push(&stack, 30);

    display(stack);

    printf("Top element is %d\n", peek(stack));

    pop(&stack);
    pop(&stack);

    display(stack);

    printf("Is stack empty? %s\n", isEmpty(stack) ? "Yes" : "No");

    pop(&stack);
    pop(&stack); // Trying to pop from an empty stack

    return 0;
}
