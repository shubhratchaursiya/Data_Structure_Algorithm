#include<stdio.h>
#include<conio.h>
int main(){
    int ch=1,n=5,arr[5],max=n-1,top=-1,value;
    printf("choice:\n 1.Push\n 2.pop\n 4.inseret\n4.exit");
    while(ch)
    {
        printf("\nenter choice");
        scanf("%d",& ch);
        switch(ch){
            case 1:
            {if (top==max)
            printf("stack is overflow");}
        else {
            top=top+1;
            printf("push the ele",value);
            a[top]=value;


        };
case 2:
{if (top==-1)
printf("stack is underflow");
else 
    printf("pop the element",a[top]);
    top=top-1;

        }
case 3:
if(top==-1){
    else
    printf("stack is:");
    for(i=top;i<=0;i++)
    printf("%d",a[i]);
    }
    case:4
    exit;
        }