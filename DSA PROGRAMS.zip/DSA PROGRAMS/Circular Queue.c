#include <stdio.h>
#include <stdlib.h>

typedef struct CircularQueue {
    int *arr;
    int front;
    int rear;
    int capacity;
} CircularQueue;

CircularQueue* createCircularQueue(int capacity) {
    CircularQueue *queue = (CircularQueue *)malloc(sizeof(CircularQueue));
    queue->capacity = capacity;
    queue->front = queue->rear = 0;
    queue->arr = (int *)malloc(capacity * sizeof(int));
    return queue;
}

int isFull(CircularQueue *queue) {
    return (queue->rear + 1) % queue->capacity == queue->front;
}

int isEmpty(CircularQueue *queue) {
    return queue->front == queue->rear;
}

void enqueue(CircularQueue *queue, int value) {
    if (isFull(queue)) {
        printf("Circular Queue Overflow! Cannot enqueue %d.\n", value);
        return;
    }
    queue->arr[queue->rear] = value;
    queue->rear = (queue->rear + 1) % queue->capacity;
    printf("%d enqueued to the circular queue.\n", value);
}

int dequeue(CircularQueue *queue) {
    if (isEmpty(queue)) {
        printf("Circular Queue Underflow! Cannot dequeue.\n");
        return -1;
    }
    int dequeuedValue = queue->arr[queue->front];
    queue->front = (queue->front + 1) % queue->capacity;
    printf("%d dequeued from the circular queue.\n", dequeuedValue);
    return dequeuedValue;
}

void displayCircularQueue(CircularQueue *queue) {
    if (isEmpty(queue)) {
        printf("Circular Queue is empty!\n");
        return;
    }
    printf("Circular Queue elements: ");
    for (int i = queue->front; i != queue->rear; i = (i + 1) % queue->capacity) {
        printf("%d ", queue->arr[i]);
    }
    printf("\n");
}

int main() {
    int capacity;
    printf("Enter the capacity of the circular queue: ");
    scanf("%d", &capacity);

    CircularQueue *queue = createCircularQueue(capacity);
    int choice, value;

    do {
        printf("\n1. Enqueue\n2. Dequeue\n3. Display Circular Queue\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to enqueue: ");
                scanf("%d", &value);
                enqueue(queue, value);
                break;
            case 2:
                dequeue(queue);
                break;
            case 3:
                displayCircularQueue(queue);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while (choice != 4);

    free(queue->arr);
    free(queue);
    return 0;
}