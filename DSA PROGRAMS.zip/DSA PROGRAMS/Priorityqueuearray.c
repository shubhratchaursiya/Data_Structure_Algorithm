#include <stdio.h>
#include <stdlib.h>

#define MAX 100 // Maximum size of the priority queue

typedef struct {
    int data[MAX];
    int priority[MAX];
    int size;
} PriorityQueue;
// Initialize the priority queue
void init(PriorityQueue *pq) {
    pq->size = 0;
}

// Check if the priority queue is empty
int isEmpty(PriorityQueue *pq) {
    return pq->size == 0;
}

// Enqueue operation to add an element to the priority queue
void enqueue(PriorityQueue *pq, int data, int priority) {
    if (pq->size == MAX) {
        printf("Priority Queue overflow\n");
        return;
    }
    pq->data[pq->size] = data;
    pq->priority[pq->size] = priority;
    pq->size++;
    printf("%d enqueued to priority queue with priority %d\n", data, priority);
}

// Dequeue operation to remove the highest priority element from the queue
int dequeue(PriorityQueue *pq) {
    if (isEmpty(pq)) {
        printf("Priority Queue underflow\n");
        return -1;
    }
    int highestPriority = pq->priority[0];
    int index = 0;
    for (int i = 1; i < pq->size; i++) {
        if (pq->priority[i] > highestPriority) {
            highestPriority = pq->priority[i];
            index = i;
        }
    }
    int data = pq->data[index];
    for (int i = index; i < pq->size - 1; i++) {
        pq->data[i] = pq->data[i + 1];
        pq->priority[i] = pq->priority[i + 1];
    }
    pq->size--;
    return data;
}

// Peek operation to return the highest priority element without removing it
int peek(PriorityQueue *pq) {
    if (isEmpty(pq)) {
        printf("Priority Queue is empty\n");
        return -1;
    }
    int highestPriority = pq->priority[0];
    int index = 0;
    for (int i = 1; i < pq->size; i++) {
        if (pq->priority[i] > highestPriority) {
            highestPriority = pq->priority[i];
            index = i;
        }
    }
    return pq->data[index];
}

// Display operation to show all elements in the priority queue
void display(PriorityQueue *pq) {
    if (isEmpty(pq)) {
        printf("Priority Queue is empty\n");
        return;
    }
    printf("Priority Queue elements:\n");
    for (int i = 0; i < pq->size; i++) {
        printf("Data: %d, Priority: %d\n", pq->data[i], pq->priority[i]);
    }
}
int main() {
    PriorityQueue pq;
    init(&pq);

    enqueue(&pq, 10, 1);
    enqueue(&pq, 20, 2);
    enqueue(&pq, 30, 3);
    enqueue(&pq, 40, 0);

    display(&pq);

    printf("Highest priority element is %d\n", peek(&pq));

    printf("%d dequeued from priority queue\n", dequeue(&pq));
    printf("%d dequeued from priority queue\n", dequeue(&pq));

    display(&pq);

    printf("Is priority queue empty? %s\n", isEmpty(&pq) ? "Yes" : "No");

    printf("%d dequeued from priority queue\n", dequeue(&pq));
    printf("%d dequeued from priority queue\n", dequeue(&pq));
    printf("%d dequeued from priority queue\n", dequeue(&pq)); // Trying to dequeue from an empty queue

    return 0;
}
