#include <stdio.h>

int main() {
    int arr[5];
    int n = 5, top = -1;

    while (1) {
        printf("\nChoice:\n1. Push\n2. Pop\n3. Display\n4. Exit\nEnter your choice: ");
        int ch;
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                if (top == n - 1) {
                    printf("Stack overflow\n");
                } else {
                    printf("Enter the element to push: ");
                    int value;
                    scanf("%d", &value);
                    arr[++top] = value;
                    printf("Element pushed successfully.\n");
                }
                break;

            case 2:
                if (top == -1) {
                    printf("Stack underflow\n");
                } else {
                    printf("Popped element: %d\n", arr[top]);
                    top--;
                }
                break;

            case 3:
                if (top == -1) {
                    printf("Stack is empty\n");
                } else {
                    printf("Stack elements: ");
                    for (int i = top; i >= 0; i--) {
                        printf("%d ", arr[i]);
                    }
                    printf("\n");
                }
                break;

            case 4:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}