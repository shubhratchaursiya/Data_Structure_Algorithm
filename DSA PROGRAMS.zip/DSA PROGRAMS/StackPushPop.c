#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int stack[MAX]; 
int top = -1;  

void push();
int pop();
void traverse();
int peek();

int main() {
    int choice;
    char ch;

    do {
        printf("1. Push\n2. Pop\n3. Traverse\n4. Peek\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: push();
                break;
            case 2: pop();
                break;
            case 3: traverse();
                break;
            case 4: peek();
                break;
            default: printf("Wrong choice! Please try again.\n");
        }

        printf("Do you want to continue? (y/n): ");
        fflush(stdin); 
        scanf(" %c", &ch); 
    } while (ch == 'y' || ch == 'Y');

    return 0;
}

void push() {
    int item;

    if (top == MAX - 1) {
        printf("Stack Overflow!\n");
    } else {
        printf("Enter the item to push: ");
        scanf("%d", &item);
        top++;
        stack[top] = item;
        printf("%d pushed onto the stack.\n", item);
    }
}

int pop() {
    if (top == -1) {
        printf("Stack Underflow!\n");
        return -1;
    } else {
        int item = stack[top];
        top--;
        printf("%d popped from the stack.\n", item);
        return item;
    }
}

void traverse() {
    if (top == -1) {
        printf("Stack is empty!\n");
    } else {
        printf("Stack elements are:\n");
        for (int i = top; i >= 0; i--) {
            printf("%d\n", stack[i]);
        }
    }
}

int peek() {
    if (top == -1) {
        printf("Stack is empty!\n");
        return -1;
    } else {
        printf("Top element is: %d\n", stack[top]);
        return stack[top];
    }
}